# Tasks list and probable roadmap

| Task | Reporter |  Reported on | Target | Status | Remarks |
| --- | --- | --- | --- | --- | --- |
|Add feature to mark preffered device in case multiple<br /> devices (network interfaces) are active. | Author | 2021-10-07 | version 9 | Complete ✓ |
|Add support for gnome 40 (Ubuntu 21.10). | User | 2021-11-03 | version 10 | Complete ✓ |
|Show both download and upload speeds side-by-side.| User | 2021-09-28 | version 11 | Complete ✓ |
|Add support for gnome 41 (Ubuntu 21.10). | User | 2022-01-04 | version 11 | Complete ✓ |
|Feature request: only show data usage over metered connections.| User | 2022-02-24 | TBD | Todo |
|Improve UI for dark theme| Author | 2021-09-09 | TBD | Todo |
|Improve documentation use JSDoc markup | Author | 2021-09-09 | TBD | InProgress |
|Add some unit tests and continuous integration.| Author | 2021-09-09 | TBD | Todo |
|Add weekly, monthly network-stat reports feature.| User | 2021-08-08 | TBD | Todo |
|Migrate to flutter depending on community support.| Author | 2021-09-09 | TBD | Todo |
